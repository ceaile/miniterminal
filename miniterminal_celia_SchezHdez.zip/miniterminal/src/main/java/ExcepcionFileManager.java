
public class ExcepcionFileManager extends Exception{

    /**
     * Creates a new instance of <code>ExcepcionFileManager</code> without
     * detail message.
     */
    public ExcepcionFileManager() {
    }

    /**
     * Constructs an instance of <code>ExcepcionFileManager</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public ExcepcionFileManager(String msg) {
        super(msg);
    }
}
